const currentPipeline = {
  id: `pipeline_${Date.now()}`,
  originalQuestion: '',
  optimizedQuestion: '',
};

function initBeyondContinue() {
  setupAutoCapture();
  setupQuestionTracking();
  createOverlayPanel();
}

function setupAutoCapture() {
  console.log('Beyond Continue: Auto capture setup');
  setupFlowMonitor();
}

function setupQuestionTracking() {
  const observer = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== 1) continue;
        const text = node.textContent?.trim();
        if (!text || text.length < 8) continue;

        if (isUserMessageNode(node)) {
          currentPipeline.originalQuestion = text;
          currentPipeline.optimizedQuestion = text;
          console.log('[Beyond Continue] Captured question:', text);
        }
      }
    }
  });

  observer.observe(document.body, { childList: true, subtree: true });
}

function isUserMessageNode(node) {
  const className = (node.className || '').toString().toLowerCase();
  const text = node.textContent?.trim() || '';
  if (className.includes('user') || className.includes('input') || className.includes('prompt')) return true;
  if (text && text.split('\n').length === 1 && text.length < 180 && /\?$/.test(text)) return true;
  return false;
}

let lastAiMessage = '';
let aiClarificationCount = 0;

function setupFlowMonitor() {
  const observer = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== 1) continue;
        const text = node.textContent?.trim();
        if (!text || text === lastAiMessage) continue;

        if (isAiResponseNode(node)) {
          handleAiResponse(text);
        }

        lastAiMessage = text;
      }
    }
  });

  const selectors = ['.response-container', '.markdown', '.prose', 'div[data-is-streaming]', '.assistant', '.bot', '.ai-response'];
  const targetNode = document.querySelector(selectors.join(', ')) || document.body;
  observer.observe(targetNode, { childList: true, subtree: true });
}

function isAiResponseNode(node) {
  const className = (node.className || '').toString().toLowerCase();
  if (className.includes('assistant') || className.includes('bot') || className.includes('ai-response') || className.includes('response')) {
    return true;
  }
  return false;
}

function handleAiResponse(text) {
  const clarificationKeywords = ['could you clarify', 'please specify', 'i need more info', 'which symbol', 'what timeframe', 'can you provide more', 'unclear'];
  const isClarification = clarificationKeywords.some((keyword) => text.toLowerCase().includes(keyword));

  chrome.runtime.sendMessage({
    type: 'SAVE_AI_RESPONSE',
    payload: {
      answerText: text,
      pipelineId: currentPipeline.id,
      question: currentPipeline.originalQuestion,
      optimizedQuestion: currentPipeline.optimizedQuestion,
      url: window.location.href,
      source: window.location.hostname,
    },
  }, (response) => {
    if (response?.success) {
      console.log('[Beyond Continue] Saved AI response locally');
      updateOverlayStatus();
    }
  });

  if (isClarification) {
    aiClarificationCount++;
    console.log(`[Flow Monitor] AI asked for clarification (${aiClarificationCount}). Prompt might need optimization.`);
    chrome.runtime.sendMessage({
      type: 'FLAG_WEAK_PROMPT',
      data: {
        pipelineId: currentPipeline.id,
        reason: 'AI_asked_clarification',
        aiResponse: text.substring(0, 200),
        url: window.location.href,
      },
    });
  }
}

function getStorageValue(key, defaultValue) {
  return new Promise((resolve) => {
    chrome.storage.local.get([key], (store) => {
      resolve(store[key] !== undefined ? store[key] : defaultValue);
    });
  });
}

function createOverlayPanel() {
  if (document.getElementById('beyond-continue-overlay')) return;

  const style = document.createElement('style');
  style.textContent = `
    #beyond-continue-overlay { position: fixed; right: 16px; top: 80px; width: 360px; max-height: 70vh; background: rgba(18, 18, 18, 0.94); color: #f5f5f5; border: 1px solid rgba(255,255,255,0.12); border-radius: 12px; box-shadow: 0 24px 80px rgba(0,0,0,0.35); z-index: 2147483647; display: flex; flex-direction: column; font-family: system-ui, sans-serif; }
    #beyond-continue-overlay header { cursor: grab; padding: 12px 14px; display: flex; align-items: center; justify-content: space-between; background: rgba(255,255,255,0.06); border-bottom: 1px solid rgba(255,255,255,0.12); }
    #beyond-continue-overlay header h2 { margin: 0; font-size: 14px; letter-spacing: 0.02em; }
    #beyond-continue-overlay .body { padding: 12px 14px; overflow: auto; }
    #beyond-continue-overlay .item { margin-bottom: 10px; }
    #beyond-continue-overlay .item strong { display: block; margin-bottom: 4px; font-size: 13px; }
    #beyond-continue-overlay .value { font-size: 13px; line-height: 1.5; color: #e0e0e0; }
    #beyond-continue-overlay button { background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.14); color: #f5f5f5; border-radius: 10px; padding: 6px 10px; cursor: pointer; font-size: 12px; }
    #beyond-continue-overlay button:hover { background: rgba(255,255,255,0.16); }
  `;
  document.head.appendChild(style);

  const overlay = document.createElement('div');
  overlay.id = 'beyond-continue-overlay';
  overlay.innerHTML = `
    <header>
      <h2>Beyond Continue</h2>
      <button id="btex-close">×</button>
    </header>
    <div class="body">
      <div class="item"><strong>Question</strong><div class="value" id="btex-question">Waiting for question...</div></div>
      <div class="item"><strong>Optimized</strong><div class="value" id="btex-optimized">Waiting for optimization...</div></div>
      <div class="item"><strong>AI responses</strong><div class="value" id="btex-count">0 saved</div></div>
      <div class="item"><strong>Clarification hits</strong><div class="value" id="btex-clarity">0</div></div>
      <div class="item"><button id="btex-refresh">Refresh</button></div>
    </div>
  `;
  document.body.appendChild(overlay);

  const closeBtn = overlay.querySelector('#btex-close');
  closeBtn.addEventListener('click', () => overlay.style.display = 'none');

  const refreshBtn = overlay.querySelector('#btex-refresh');
  refreshBtn.addEventListener('click', updateOverlayStatus);

  makeOverlayDraggable(overlay, overlay.querySelector('header'));
  updateOverlayStatus();
}

function makeOverlayDraggable(overlay, handle) {
  let isDragging = false;
  let startX = 0;
  let startY = 0;
  let startLeft = 0;
  let startTop = 0;

  handle.addEventListener('mousedown', (event) => {
    isDragging = true;
    startX = event.clientX;
    startY = event.clientY;
    const rect = overlay.getBoundingClientRect();
    startLeft = rect.left;
    startTop = rect.top;
    handle.style.cursor = 'grabbing';
    event.preventDefault();
  });

  window.addEventListener('mousemove', (event) => {
    if (!isDragging) return;
    const dx = event.clientX - startX;
    const dy = event.clientY - startY;
    overlay.style.right = 'auto';
    overlay.style.left = `${Math.min(window.innerWidth - overlay.offsetWidth - 10, Math.max(10, startLeft + dx))}px`;
    overlay.style.top = `${Math.min(window.innerHeight - overlay.offsetHeight - 10, Math.max(10, startTop + dy))}px`;
  });

  window.addEventListener('mouseup', () => {
    if (!isDragging) return;
    isDragging = false;
    handle.style.cursor = 'grab';
  });
}

async function updateOverlayStatus() {
  const questionEl = document.getElementById('btex-question');
  const optimizedEl = document.getElementById('btex-optimized');
  const countEl = document.getElementById('btex-count');
  const clarityEl = document.getElementById('btex-clarity');
  if (!questionEl || !optimizedEl || !countEl || !clarityEl) return;

  questionEl.textContent = currentPipeline.originalQuestion || 'Waiting for question...';
  optimizedEl.textContent = currentPipeline.optimizedQuestion || 'Waiting for optimization...';
  const store = await getStorageValue('aiResponseHistory', []);
  const responses = store || [];
  countEl.textContent = `${responses.length} saved`;
  clarityEl.textContent = `${aiClarificationCount}`;
}

initBeyondContinue();